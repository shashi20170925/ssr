const bundle = require("./build/bundle");

module.exports.myHandler = bundle.handler;
