// const bundle = require("./build/bundle");

// module.exports.ssr_new = bundle.handler;
